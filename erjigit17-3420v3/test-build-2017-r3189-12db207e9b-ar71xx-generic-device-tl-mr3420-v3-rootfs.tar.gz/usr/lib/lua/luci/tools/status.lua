module("luci.tools.status",package.seeall)
local h=require"luci.model.uci".cursor()
local function d(i)
local e={}
local r=require"nixio.fs"
local t="/tmp/dhcp.leases"
h:foreach("dhcp","dnsmasq",
function(e)
if e.leasefile and r.access(e.leasefile)then
t=e.leasefile
return false
end
end)
local s=io.open(t,"r")
if s then
while true do
local t=s:read("*l")
if not t then
break
else
local s,h,a,t,n=t:match("^(%d+) (%S+) (%S+) (%S+) (%S+)")
local o=tonumber(s)or 0
if s and h and a and t and n then
if i==4 and not a:match(":")then
e[#e+1]={
expires=(o~=0)and os.difftime(o,os.time()),
macaddr=h,
ipaddr=a,
hostname=(t~="*")and t
}
elseif i==6 and a:match(":")then
e[#e+1]={
expires=(o~=0)and os.difftime(o,os.time()),
ip6addr=a,
duid=(n~="*")and n,
hostname=(t~="*")and t
}
end
end
end
end
s:close()
end
local t="/tmp/hosts/odhcpd"
h:foreach("dhcp","odhcpd",
function(e)
if e.leasefile and r.access(e.leasefile)then
t=e.leasefile
return false
end
end)
local n=io.open(t,"r")
if n then
while true do
local t=n:read("*l")
if not t then
break
else
local h,n,s,t,a,h,h,o=t:match("^# (%S+) (%S+) (%S+) (%S+) (-?%d+) (%S+) (%S+) (.*)")
local a=tonumber(a)or 0
if o and s~="ipv4"and i==6 then
e[#e+1]={
expires=(a>=0)and os.difftime(a,os.time()),
duid=n,
ip6addr=o,
hostname=(t~="-")and t
}
elseif o and s=="ipv4"and i==4 then
e[#e+1]={
expires=(a>=0)and os.difftime(a,os.time()),
macaddr=n,
ipaddr=o,
hostname=(t~="-")and t
}
end
end
end
n:close()
end
return e
end
function dhcp_leases()
return d(4)
end
function dhcp6_leases()
return d(6)
end
function wifi_networks()
local o={}
local e=require"luci.model.network".init()
local t
for e,t in ipairs(e:get_wifidevs())do
local a={
up=t:is_up(),
device=t:name(),
name=t:get_i18n(),
networks={}
}
local e
for i,e in ipairs(t:get_wifinets())do
a.networks[#a.networks+1]={
name=e:shortname(),
link=e:adminlink(),
up=e:is_up(),
mode=e:active_mode(),
ssid=e:active_ssid(),
bssid=e:active_bssid(),
encryption=e:active_encryption(),
frequency=e:frequency(),
channel=e:channel(),
signal=e:signal(),
quality=e:signal_percent(),
noise=e:noise(),
bitrate=e:bitrate(),
ifname=e:ifname(),
assoclist=e:assoclist(),
country=e:country(),
txpower=e:txpower(),
txpoweroff=e:txpower_offset(),
disabled=(t:get("disabled")=="1"or
e:get("disabled")=="1")
}
end
o[#o+1]=a
end
return o
end
function wifi_network(a)
local e=require"luci.model.network".init()
local e=e:get_wifinet(a)
if e then
local t=e:get_device()
if t then
return{
id=a,
name=e:shortname(),
link=e:adminlink(),
up=e:is_up(),
mode=e:active_mode(),
ssid=e:active_ssid(),
bssid=e:active_bssid(),
encryption=e:active_encryption(),
frequency=e:frequency(),
channel=e:channel(),
signal=e:signal(),
quality=e:signal_percent(),
noise=e:noise(),
bitrate=e:bitrate(),
ifname=e:ifname(),
assoclist=e:assoclist(),
country=e:country(),
txpower=e:txpower(),
txpoweroff=e:txpower_offset(),
disabled=(t:get("disabled")=="1"or
e:get("disabled")=="1"),
device={
up=t:is_up(),
device=t:name(),
name=t:get_i18n()
}
}
end
end
return{}
end
function switch_status(e)
local t
local o={}
for i in e:gmatch("[^%s,]+")do
local a={}
local t=io.popen("swconfig dev %q show"%i,"r")
if t then
local e
repeat
e=t:read("*l")
if e then
local t,n=e:match("port:(%d+) link:(%w+)")
if t then
local s=e:match(" speed:(%d+)")
local i=e:match(" (%w+)-duplex")
local o=e:match(" (txflow)")
local h=e:match(" (rxflow)")
local e=e:match(" (auto)")
a[#a+1]={
port=tonumber(t)or 0,
speed=tonumber(s)or 0,
link=(n=="up"),
duplex=(i=="full"),
rxflow=(not not h),
txflow=(not not o),
auto=(not not e)
}
end
end
until not e
t:close()
end
o[i]=a
end
return o
end
