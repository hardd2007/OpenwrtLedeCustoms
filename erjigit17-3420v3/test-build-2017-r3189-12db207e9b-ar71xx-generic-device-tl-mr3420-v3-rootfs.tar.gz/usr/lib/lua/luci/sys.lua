local s=require"io"
local c=require"os"
local h=require"table"
local t=require"nixio"
local i=require"nixio.fs"
local d=require"luci.model.uci"
local a={}
a.util=require"luci.util"
a.ip=require"luci.ip"
local o,f,p,w,u,e,y,v,m=
tonumber,ipairs,pairs,pcall,type,next,setmetatable,require,select
module"luci.sys"
function call(...)
return c.execute(...)/256
end
exec=a.util.exec
function mounts()
local n={}
local o={"fs","blocks","used","available","percent","mountpoint"}
local a=a.util.execi("df")
if not a then
return
else
a()
end
for i in a do
local t={}
local e=1
for a in i:gmatch("[^%s]+")do
t[o[e]]=a
e=e+1
end
if t[o[1]]then
if not t[o[2]]then
e=2
i=a()
for a in i:gmatch("[^%s]+")do
t[o[e]]=a
e=e+1
end
end
h.insert(n,t)
end
end
return n
end
getenv=t.getenv
function hostname(e)
if u(e)=="string"and#e>0 then
i.writefile("/proc/sys/kernel/hostname",e)
return e
else
return t.uname().nodename
end
end
function httpget(t,o,e)
if not e then
local e=o and s.popen or a.util.exec
return e("wget -qO- '"..t:gsub("'","").."'")
else
return c.execute("wget -qO '%s' '%s'"%
{e:gsub("'",""),t:gsub("'","")})
end
end
function reboot()
return c.execute("reboot >/dev/null 2>&1")
end
function syslog()
return a.util.exec("logread")
end
function dmesg()
return a.util.exec("dmesg")
end
function uniqueid(e)
local e=i.readfile("/dev/urandom",e)
return e and t.bin.hexlify(e)
end
function uptime()
return t.sysinfo().uptime
end
net={}
function net.arptable(a)
local t=(not a)and{}or nil
local o,o,e
if i.access("/proc/net/arp")then
for o in s.lines("/proc/net/arp")do
local e={},e
for t in o:gmatch("%S+")do
e[#e+1]=t
end
if e[1]~="IP"then
local e={
["IP address"]=e[1],
["HW type"]=e[2],
["Flags"]=e[3],
["HW address"]=e[4],
["Mask"]=e[5],
["Device"]=e[6]
}
if a then
a(e)
else
t=t or{}
t[#t+1]=e
end
end
end
end
return t
end
local function n(n,w)
local e,e,e,r,h,u
local c=d.cursor()
local d={}
local o={}
local function l(e,...)
local e=m(e,...)
if e then
if not o[e]then o[e]={}end
o[e][1]=m(1,...)or o[e][1]
o[e][2]=m(2,...)or o[e][2]
o[e][3]=m(3,...)or o[e][3]
o[e][4]=m(4,...)or o[e][4]
end
end
a.ip.neighbors(nil,function(e)
if e.mac and e.family==4 then
l(n,e.mac:upper(),e.dest:string(),nil,nil)
elseif e.mac and e.family==6 then
l(n,e.mac:upper(),nil,e.dest:string(),nil)
end
end)
if i.access("/etc/ethers")then
for e in s.lines("/etc/ethers")do
r,h=e:match("^([a-f0-9]%S+) (%S+)")
if r and h then
l(n,r:upper(),h,nil,nil)
end
end
end
c:foreach("dhcp","dnsmasq",
function(e)
if e.leasefile and i.access(e.leasefile)then
for e in s.lines(e.leasefile)do
r,h,u=e:match("^%d+ (%S+) (%S+) (%S+)")
if r and h then
l(n,r:upper(),h,nil,u~="*"and u)
end
end
end
end
)
c:foreach("dhcp","host",
function(e)
for t in a.util.imatch(e.mac)do
l(n,t:upper(),e.ip,nil,e.name)
end
end)
for t,e in f(t.getifaddrs())do
if e.name~="lo"then
d[e.name]=d[e.name]or{}
if e.family=="packet"and e.addr and#e.addr==17 then
d[e.name][1]=e.addr:upper()
elseif e.family=="inet"then
d[e.name][2]=e.addr
elseif e.family=="inet6"then
d[e.name][3]=e.addr
end
end
end
for t,e in p(d)do
if e[n]and(e[2]or e[3])then
l(n,e[1],e[2],e[3],e[4])
end
end
for t,e in a.util.kspairs(o)do
w(e[1],e[2],e[3],e[4])
end
end
function net.mac_hints(o)
if o then
n(1,function(n,a,i,e)
e=e or t.getnameinfo(a or i,nil,100)or a
if e and e~=n then
o(n,e or t.getnameinfo(a or i,nil,100)or a)
end
end)
else
local o={}
n(1,function(n,a,i,e)
e=e or t.getnameinfo(a or i,nil,100)or a
if e and e~=n then
o[#o+1]={n,e or t.getnameinfo(a or i,nil,100)or a}
end
end)
return o
end
end
function net.ipv4_hints(o)
if o then
n(2,function(i,a,n,e)
e=e or t.getnameinfo(a,nil,100)or i
if e and e~=a then
o(a,e)
end
end)
else
local o={}
n(2,function(i,a,n,e)
e=e or t.getnameinfo(a,nil,100)or i
if e and e~=a then
o[#o+1]={a,e}
end
end)
return o
end
end
function net.ipv6_hints(o)
if o then
n(3,function(i,n,a,e)
e=e or t.getnameinfo(a,nil,100)or i
if e and e~=a then
o(a,e)
end
end)
else
local a={}
n(3,function(i,n,o,e)
e=e or t.getnameinfo(o,nil,100)or i
if e and e~=o then
a[#a+1]={o,e}
end
end)
return a
end
end
function net.host_hints(i)
if i then
n(1,function(e,o,t,a)
if e and e~="00:00:00:00:00:00"and(o or t or a)then
i(e,o,t,a)
end
end)
else
local s={}
n(1,function(i,o,t,a)
if i and i~="00:00:00:00:00:00"and(o or t or a)then
local e={}
if o then e.ipv4=o end
if t then e.ipv6=t end
if a then e.name=a end
s[i]=e
end
end)
return s
end
end
function net.conntrack(n)
local i,e=w(s.lines,"/proc/net/nf_conntrack")
if not i or not e then
return nil
end
local i,s=nil,(not n)and{}
for e in e do
local h,d,e,r,i=
e:match("^(ipv[46]) +(%d+) +%S+ +(%d+) +(%d+) +(.+)$")
if h and d and e and r and not i:match("^TIME_WAIT ")then
e=t.getprotobynumber(e)
local t={
bytes=0,
packets=0,
layer3=h,
layer4=e and e.name or"unknown",
timeout=o(r,10)
}
local e,e
for e,i in i:gmatch("(%w+)=(%S+)")do
if e=="bytes"or e=="packets"then
t[e]=t[e]+o(i,10)
elseif e=="src"or e=="dst"then
if t[e]==nil then
t[e]=a.ip.new(i):string()
end
elseif e=="sport"or e=="dport"then
if t[e]==nil then
t[e]=i
end
elseif i then
t[e]=i
end
end
if n then
n(t)
else
s[#s+1]=t
end
end
end
return n and true or s
end
function net.devices()
local e={}
for a,t in f(t.getifaddrs())do
if t.family=="packet"then
e[#e+1]=t.name
end
end
return e
end
function net.deviceinfo()
local a={}
for e,t in f(t.getifaddrs())do
if t.family=="packet"then
local e=t.data
e[1]=e.rx_bytes
e[2]=e.rx_packets
e[3]=e.rx_errors
e[4]=e.rx_dropped
e[5]=0
e[6]=0
e[7]=0
e[8]=e.multicast
e[9]=e.tx_bytes
e[10]=e.tx_packets
e[11]=e.tx_errors
e[12]=e.tx_dropped
e[13]=0
e[14]=e.collisions
e[15]=0
e[16]=0
a[t.name]=e
end
end
return a
end
function net.routes(h)
local n={}
for e in s.lines("/proc/net/route")do
local s,t,i,u,l,m,d,
e,r,f,c=e:match(
"([^%s]+)\t([A-F0-9]+)\t([A-F0-9]+)\t([A-F0-9]+)\t"..
"(%d+)\t(%d+)\t(%d+)\t([A-F0-9]+)\t(%d+)\t(%d+)\t(%d+)"
)
if s then
i=a.ip.Hex(i,32,a.ip.FAMILY_INET4)
e=a.ip.Hex(e,32,a.ip.FAMILY_INET4)
t=a.ip.Hex(
t,e:prefix(e),a.ip.FAMILY_INET4
)
local e={
dest=t,
gateway=i,
metric=o(d),
refcount=o(l),
usecount=o(m),
mtu=o(r),
window=o(window),
irtt=o(c),
flags=o(u,16),
device=s
}
if h then
h(e)
else
n[#n+1]=e
end
end
end
return n
end
function net.routes6(c)
if i.access("/proc/net/ipv6_route","r")then
local h={}
for e in s.lines("/proc/net/ipv6_route")do
local e,u,t,r,i,
n,l,d,s,m=e:match(
"([a-f0-9]+) ([a-f0-9]+) "..
"([a-f0-9]+) ([a-f0-9]+) "..
"([a-f0-9]+) ([a-f0-9]+) "..
"([a-f0-9]+) ([a-f0-9]+) "..
"([a-f0-9]+) +([^%s]+)"
)
if e and u and
t and r and
i and n and
l and d and
s and m
then
t=a.ip.Hex(
t,o(r,16),a.ip.FAMILY_INET6,false
)
e=a.ip.Hex(
e,o(u,16),a.ip.FAMILY_INET6,false
)
i=a.ip.Hex(i,128,a.ip.FAMILY_INET6,false)
local e={
source=t,
dest=e,
nexthop=i,
metric=o(n,16),
refcount=o(l,16),
usecount=o(d,16),
flags=o(s,16),
device=m,
metric_raw=n
}
if c then
c(e)
else
h[#h+1]=e
end
end
end
return h
end
end
function net.pingtest(e)
return c.execute("ping -c1 '"..e:gsub("'",'').."' >/dev/null 2>&1")
end
process={}
function process.info(a)
local e={uid=t.getuid(),gid=t.getgid()}
return not a and e or e[a]
end
function process.list()
local i={}
local e
local e=a.util.execi("/bin/busybox top -bn1")
if not e then
return
end
for e in e do
local t,s,n,a,r,l,d,h=e:match(
"^ *(%d+) +(%d+) +(%S.-%S) +([RSDZTW][W ][<N ]) +(%d+) +(%d+%%) +(%d+%%) +(.+)"
)
local e=o(t)
if e then
i[e]={
['PID']=t,
['PPID']=s,
['USER']=n,
['STAT']=a,
['VSZ']=r,
['%MEM']=l,
['%CPU']=d,
['COMMAND']=h
}
end
end
return i
end
function process.setgroup(e)
return t.setgid(e)
end
function process.setuser(e)
return t.setuid(e)
end
process.signal=t.kill
user={}
user.getuser=t.getpw
function user.getpasswd(e)
local e=t.getsp and t.getsp(e)or t.getpw(e)
local t=e and(e.pwdp or e.passwd)
if not t or#t<1 or t=="!"or t=="x"then
return nil,e
else
return t,e
end
end
function user.checkpasswd(e,a)
local e,o=user.getpasswd(e)
if o then
return(e==nil or t.crypt(a,e)==e)
end
return false
end
function user.setpasswd(t,e)
if e then
e=e:gsub("'",[['"'"']])
end
if t then
t=t:gsub("'",[['"'"']])
end
return c.execute(
"(echo '"..e.."'; sleep 1; echo '"..e.."') | "..
"passwd '"..t.."' >/dev/null 2>&1"
)
end
wifi={}
function wifi.getiwinfo(e)
local s,n=w(v,"iwinfo")
if e then
local t,i=e:match("^(%w+)%.network(%d+)")
local a=a.util.ubus("network.wireless","status")or{}
t=t or e
i=i and o(i)or 1
if u(a[t])=="table"and
u(a[t].interfaces)=="table"and
u(a[t].interfaces[i])=="table"and
u(a[t].interfaces[i].ifname)=="string"
then
e=a[t].interfaces[i].ifname
else
e=t
end
local t=s and n.type(e)
local a=t and n[t]or{}
return y({},{
__index=function(o,t)
if t=="ifname"then
return e
elseif a[t]then
return a[t](e)
end
end
})
end
end
init={}
init.dir="/etc/init.d/"
function init.names()
local e={}
for t in i.glob(init.dir.."*")do
e[#e+1]=i.basename(t)
end
return e
end
function init.index(e)
if i.access(init.dir..e)then
return call("env -i sh -c 'source %s%s enabled; exit ${START:-255}' >/dev/null"
%{init.dir,e})
end
end
local function e(t,e)
if i.access(init.dir..e)then
return call("env -i %s%s %s >/dev/null"%{init.dir,e,t})
end
end
function init.enabled(t)
return(e("enabled",t)==0)
end
function init.enable(t)
return(e("enable",t)==1)
end
function init.disable(t)
return(e("disable",t)==0)
end
function init.start(t)
return(e("start",t)==0)
end
function init.stop(t)
return(e("stop",t)==0)
end
