local n=require"luci.dispatcher"
local i=require"luci.model.firewall"
local a,e,t,o,s,s
a=Map("firewall",
translate("Firewall - Zone Settings"),
translate("The firewall creates zones over your network interfaces to control network traffic flow."))
i.init(a.uci)
e=a:section(TypedSection,"defaults",translate("General Settings"))
e.anonymous=true
e.addremove=false
e:option(Flag,"syn_flood",translate("Enable SYN-flood protection"))
t=e:option(Flag,"drop_invalid",translate("Drop invalid packets"))
t.default=t.enabled
o={
e:option(ListValue,"input",translate("Input")),
e:option(ListValue,"output",translate("Output")),
e:option(ListValue,"forward",translate("Forward"))
}
for a,t in ipairs(o)do
t:value("REJECT",translate("reject"))
t:value("DROP",translate("drop"))
t:value("ACCEPT",translate("accept"))
end
e=a:section(TypedSection,"zone",translate("Zones"))
e.template="cbi/tblsection"
e.anonymous=true
e.addremove=true
e.extedit=n.build_url("admin","network","firewall","zones","%s")
function e.create(e)
local e=i:new_zone()
if e then
luci.http.redirect(
n.build_url("admin","network","firewall","zones",e.sid)
)
end
end
function e.remove(a,e)
return i:del_zone(e)
end
t=e:option(DummyValue,"_info",translate("Zone ⇒ Forwardings"))
t.template="cbi/firewall_zoneforwards"
t.cfgvalue=function(e,t)
return e.map:get(t,"name")
end
o={
e:option(ListValue,"input",translate("Input")),
e:option(ListValue,"output",translate("Output")),
e:option(ListValue,"forward",translate("Forward"))
}
for a,t in ipairs(o)do
t:value("REJECT",translate("reject"))
t:value("DROP",translate("drop"))
t:value("ACCEPT",translate("accept"))
end
e:option(Flag,"masq",translate("Masquerading"))
e:option(Flag,"mtu_fix",translate("MSS clamping"))
return a
