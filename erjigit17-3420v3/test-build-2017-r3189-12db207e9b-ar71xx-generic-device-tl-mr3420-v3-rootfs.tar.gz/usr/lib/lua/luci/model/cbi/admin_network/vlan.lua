m=Map("network",translate("Switch"),translate("The network ports on this device can be combined to several <abbr title=\"Virtual Local Area Network\">VLAN</abbr>s in which computers can communicate directly with each other. <abbr title=\"Virtual Local Area Network\">VLAN</abbr>s are often used to separate different network segments. Often there is by default one Uplink port for a connection to the next greater network like the internet and other ports for a local network."))
local e=require"nixio.fs"
local e=require"luci.model.network"
local r={}
e.init(m.uci)
local e=e:get_switch_topologies()or{}
m.uci:foreach("network","switch",
function(o)
local p=o['.name']
local t=o.name or p
local l=nil
local f=nil
local a=nil
local c=nil
local w=nil
local h=0
local i=16
local d=16
local i
local y=false
local n=e[t]
if not n then
m.message=translatef("Switch %q has an unknown topology - the VLAN settings might not be accurate.",t)
n={
ports={
{num=0,label="Port 1"},
{num=1,label="Port 2"},
{num=2,label="Port 3"},
{num=3,label="Port 4"},
{num=4,label="Port 5"},
{num=5,label="CPU (eth0)",tagged=false}
}
}
end
local u=io.popen("swconfig dev %q help 2>/dev/null"%t)
if u then
local o=false
local t=false
while true do
local e=u:read("*l")
if not e then break end
if e:match("^%s+%-%-vlan")then
t=true
elseif e:match("^%s+%-%-port")then
t=false
o=true
elseif e:match("cpu @")then
i=e:match("^switch%d: %w+%((.-)%)")
d=tonumber(e:match("vlans: (%d+)"))or 16
h=1
elseif e:match(": pvid")or e:match(": tag")or e:match(": vid")then
if t then a=e:match(": (%w+)")end
elseif e:match(": enable_vlan4k")then
y=true
elseif e:match(": enable_vlan")then
l="enable_vlan"
elseif e:match(": enable_learning")then
f="enable_learning"
elseif e:match(": enable_mirror_rx")then
w="enable_mirror_rx"
elseif e:match(": max_length")then
c="max_length"
end
end
u:close()
end
s=m:section(NamedSection,o['.name'],"switch",
i and translatef("Switch %q (%s)",t,i)
or translatef("Switch %q",t))
s.addremove=false
if l then
s:option(Flag,l,translate("Enable VLAN functionality"))
end
if f then
o=s:option(Flag,f,translate("Enable learning and aging"))
o.default=o.enabled
end
if c then
o=s:option(Flag,c,translate("Enable Jumbo Frame passthrough"))
o.enabled="3"
o.rmempty=true
end
if w then
s:option(Flag,"enable_mirror_rx",translate("Enable mirroring of incoming packets"))
s:option(Flag,"enable_mirror_tx",translate("Enable mirroring of outgoing packets"))
local t=s:option(ListValue,"mirror_source_port",translate("Mirror source port"))
local a=s:option(ListValue,"mirror_monitor_port",translate("Mirror monitor port"))
t:depends("enable_mirror_tx","1")
t:depends("enable_mirror_rx","1")
a:depends("enable_mirror_tx","1")
a:depends("enable_mirror_rx","1")
local e,e
for o,e in ipairs(n.ports)do
t:value(e.num,e.label)
a:value(e.num,e.label)
end
end
s=m:section(TypedSection,"switch_vlan",
i and translatef("VLANs on %q (%s)",t,i)
or translatef("VLANs on %q",t))
s.template="cbi/tblsection"
s.addremove=true
s.anonymous=true
s.filter=function(a,e)
local e=m:get(e,"device")
return(e and e==t)
end
s.cfgsections=function(e)
local e=TypedSection.cfgsections(e)
local t={}
local o
for a,e in luci.util.spairs(
e,
function(t,o)
return(tonumber(m:get(e[t],a or"vlan"))or 9999)
<(tonumber(m:get(e[o],a or"vlan"))or 9999)
end
)do
t[#t+1]=e
end
return t
end
s.create=function(e,o,i)
if m:get(i,"device")~=t then
return
end
local e=TypedSection.create(e,o)
local o=0
local i=0
m.uci:foreach("network","switch_vlan",
function(e)
if e.device==t then
local t=tonumber(e.vlan)
local e=a and tonumber(e[a])
if t~=nil and t>o then o=t end
if e~=nil and e>i then i=e end
end
end)
m:set(e,"device",t)
m:set(e,"vlan",o+1)
if a then
m:set(e,a,i+1)
end
return e
end
local o={}
local i={}
local u=function(a,e)
local t
for e in(m:get(e,"ports")or""):gmatch("%w+")do
local t,e=e:match("^(%d+)([tu]*)")
if t==a.option then return(#e>0)and e or"u"end
end
return""
end
local l=function(e,t,a)
if t=="u"then
if not i[e.option]then
i[e.option]=true
else
return nil,
translatef("%s is untagged in multiple VLANs!",e.title)
end
end
return t
end
local e=s:option(Value,a or"vlan","VLAN ID","<div id='portstatus-%s'></div>"%t)
local i=a and 4094 or(d-1)
e.rmempty=false
e.forcewrite=true
e.vlan_used={}
e.datatype="and(uinteger,range("..h..","..i.."))"
e.validate=function(o,i,t)
local t=tonumber(i)
local a=a and 4094 or(d-1)
if t~=nil and t>=h and t<=a then
if not o.vlan_used[t]then
o.vlan_used[t]=true
return i
else
return nil,
translatef("Invalid VLAN ID given! Only unique IDs are allowed")
end
else
return nil,
translatef("Invalid VLAN ID given! Only IDs between %d and %d are allowed.",h,a)
end
end
e.write=function(i,a,n)
local t
local t={}
for o,e in ipairs(o)do
local a=e:formvalue(a)
if a=="t"then
t[#t+1]=e.option..a
elseif a=="u"then
t[#t+1]=e.option
end
end
if y then
m:set(p,"enable_vlan4k","1")
end
m:set(a,"ports",table.concat(t," "))
return Value.write(i,a,n)
end
e.cfgvalue=function(t,e)
return m:get(e,a or"vlan")
or m:get(e,"vlan")
end
local e,e
for e,a in ipairs(n.ports)do
local e=s:option(ListValue,tostring(a.num),a.label,'<div id="portstatus-%s-%d"></div>'%{t,a.num})
e:value("",translate("off"))
if not a.tagged then
e:value("u",translate("untagged"))
end
e:value("t",translate("tagged"))
e.cfgvalue=u
e.validate=l
e.write=function()end
o[#o+1]=e
end
table.sort(o,function(t,e)return t.option<e.option end)
r[#r+1]=t
end
)
s=m:section(SimpleSection)
s.template="admin_network/switch_status"
s.switches=r
return m
