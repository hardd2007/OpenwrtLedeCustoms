module("luci.controller.admin.status",package.seeall)
function index()
entry({"admin","status"},alias("admin","status","overview"),_("Status"),20).index=true
entry({"admin","status","overview"},template("admin_status/index"),_("Overview"),1)
entry({"admin","status","iptables"},template("admin_status/iptables"),_("Firewall"),2).leaf=true
entry({"admin","status","iptables_action"},post("action_iptables")).leaf=true
entry({"admin","status","routes"},template("admin_status/routes"),_("Routes"),3)
entry({"admin","status","syslog"},call("action_syslog"),_("System Log"),4)
entry({"admin","status","dmesg"},call("action_dmesg"),_("Kernel Log"),5)
entry({"admin","status","processes"},cbi("admin_status/processes"),_("Processes"),6)
entry({"admin","status","realtime"},alias("admin","status","realtime","load"),_("Realtime Graphs"),7)
entry({"admin","status","realtime","load"},template("admin_status/load"),_("Load"),1).leaf=true
entry({"admin","status","realtime","load_status"},call("action_load")).leaf=true
entry({"admin","status","realtime","bandwidth"},template("admin_status/bandwidth"),_("Traffic"),2).leaf=true
entry({"admin","status","realtime","bandwidth_status"},call("action_bandwidth")).leaf=true
if nixio.fs.access("/etc/config/wireless")then
entry({"admin","status","realtime","wireless"},template("admin_status/wireless"),_("Wireless"),3).leaf=true
entry({"admin","status","realtime","wireless_status"},call("action_wireless")).leaf=true
end
entry({"admin","status","realtime","connections"},template("admin_status/connections"),_("Connections"),4).leaf=true
entry({"admin","status","realtime","connections_status"},call("action_connections")).leaf=true
entry({"admin","status","nameinfo"},call("action_nameinfo")).leaf=true
end
function action_syslog()
local e=luci.sys.syslog()
luci.template.render("admin_status/syslog",{syslog=e})
end
function action_dmesg()
local e=luci.sys.dmesg()
luci.template.render("admin_status/dmesg",{dmesg=e})
end
function action_iptables()
if luci.http.formvalue("zero")then
if luci.http.formvalue("family")=="6"then
luci.util.exec("/usr/sbin/ip6tables -Z")
else
luci.util.exec("/usr/sbin/iptables -Z")
end
elseif luci.http.formvalue("restart")then
luci.util.exec("/etc/init.d/firewall restart")
end
luci.http.redirect(luci.dispatcher.build_url("admin/status/iptables"))
end
function action_bandwidth(e)
luci.http.prepare_content("application/json")
local e=io.popen("luci-bwc -i %q 2>/dev/null"%e)
if e then
luci.http.write("[")
while true do
local e=e:read("*l")
if not e then break end
luci.http.write(e)
end
luci.http.write("]")
e:close()
end
end
function action_wireless(e)
luci.http.prepare_content("application/json")
local e=io.popen("luci-bwc -r %q 2>/dev/null"%e)
if e then
luci.http.write("[")
while true do
local e=e:read("*l")
if not e then break end
luci.http.write(e)
end
luci.http.write("]")
e:close()
end
end
function action_load()
luci.http.prepare_content("application/json")
local e=io.popen("luci-bwc -l 2>/dev/null")
if e then
luci.http.write("[")
while true do
local e=e:read("*l")
if not e then break end
luci.http.write(e)
end
luci.http.write("]")
e:close()
end
end
function action_connections()
local e=require"luci.sys"
luci.http.prepare_content("application/json")
luci.http.write("{ connections: ")
luci.http.write_json(e.net.conntrack())
local e=io.popen("luci-bwc -c 2>/dev/null")
if e then
luci.http.write(", statistics: [")
while true do
local e=e:read("*l")
if not e then break end
luci.http.write(e)
end
luci.http.write("]")
e:close()
end
luci.http.write(" }")
end
function action_nameinfo(...)
local e
local t={}
for e=1,select('#',...)do
local e=select(e,...)
local a=nixio.getnameinfo(e)
t[e]=a or(e:match(":")and"[%s]"%e or e)
end
luci.http.prepare_content("application/json")
luci.http.write_json(t)
end
